package uk.co.ewanhemingway.androidome;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import com.illposed.osc.*;
import uk.co.ewanhemingway.androidome.R;

public class Androidome extends Activity implements OnClickListener {

	private OSCPortOut oscPortOut;
	public Button buttonGrid[][], clearButton;
	public boolean grid[][];
	
	String prefix = "osc";

	int gridLength = 8;
	int gridHeight = 8;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		setAddress();
		
		// initialise grid to store on/off states
		grid = new boolean[gridHeight][gridLength];

		// initialise array of Button objects
		buttonGrid = new Button[gridHeight][gridLength];
		
		TableLayout sequencerTableHolder = (TableLayout)findViewById(R.id.table_holder);
		clearButton = (Button)findViewById(R.id.clear_button);

		clearButton.setOnClickListener(new Button.OnClickListener(){ 
			public void onClick(View v) {
				initialiseGrid();
			}
		});
		
		sequencerTableHolder.setPadding(1,1,1,1);

		// initialise grid of buttons
		for (int column = 0; column < gridLength; column++) {
			TableRow tempRow = new TableRow(this);
			for (int rowElement = 0; rowElement < gridHeight; rowElement++) {
				buttonGrid[column][rowElement] = new Button (this);
				buttonGrid[column][rowElement].setOnClickListener(this);
				tempRow.addView(buttonGrid[column][rowElement], 35,35);
			}
			sequencerTableHolder.addView(tempRow);
		}

		// make sure grid is cleared
		initialiseGrid();

	}
	
	// function to wipe the board clean
	private void initialiseGrid(){

		Drawable unselectedDrawable = this.getResources().getDrawable(R.drawable.unselected);

		for (int column = 0; column < gridLength; column++) {
			for (int rowElement = 0; rowElement < gridHeight; rowElement++) {
				buttonGrid[column][rowElement].setBackgroundDrawable(unselectedDrawable);
				grid[column][rowElement] = false;
			}
		}
	}
	
	// create a method for the addressChanged action (Set Address)
	public void setAddress() {
		// the variable OSCPortOut tries to get an instance of OSCPortOut at the address

		try {
			oscPortOut = new OSCPortOut(InetAddress.getByName("192.168.1.164"));   //addressWidget.getText()));
			// if the oscPort variable fails to be instantiated then sent the error message
		} catch (Exception e) {
			showError("Couldn't set address" + e);
		}
	}

	// handler for button grid 
	public void onClick(View view) {

		Button buttonCheck = (Button) view;

		int posX = -1, posY = -1;
		for (int i = 0; i < buttonGrid[0].length; i++){
			for (int j = 0; j < buttonGrid.length; j++){
				if (buttonGrid[i][j] == buttonCheck){
					posX = i;
					posY = j;
					break;
				}
			}
		}

		Object[] args1 = {new Integer(posY), new Integer(posX), new Integer(1)};
		OSCMessage msg1 = new OSCMessage("/" + prefix + "/press", args1);
		if(grid[posX][posY]) args1[2] = 0;
		
		try {
			oscPortOut.send(msg1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			showError("Couldn't send" + e);
		}
		
		Drawable myImage;

		// flip state
		grid[posX][posY] = !grid[posX][posY];

		if(grid[posX][posY]) myImage = this.getResources().getDrawable(R.drawable.selected);
		else myImage = this.getResources().getDrawable(R.drawable.unselected);

		// and update image
		buttonGrid[posX][posY].setBackgroundDrawable(myImage);
		

	}
	
	
	// create a showError method
	protected void showError(String anErrorMessage) {
		Context context = getApplicationContext();
		int duration = Toast.LENGTH_SHORT;
		Toast toast = Toast.makeText(context, anErrorMessage, duration);
		toast.show();

	}
	
}
