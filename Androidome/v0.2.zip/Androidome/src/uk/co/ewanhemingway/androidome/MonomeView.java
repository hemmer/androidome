package uk.co.ewanhemingway.androidome;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Paint.Style;
import android.net.wifi.WifiManager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.illposed.osc.OSCListener;
import com.illposed.osc.OSCMessage;
import com.illposed.osc.OSCPort;
import com.illposed.osc.OSCPortIn;
import com.illposed.osc.OSCPortOut;

public class MonomeView extends View{

	private OSCPortOut oscPortOut;
	private OSCPortIn oscPortIn;
	int cellSize = 38;
	String prefix = "mlr";
	String deviceIPAddress = " ";
	Boolean[][] gridDown;
	
	public MonomeView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		try {
			oscPortIn = new OSCPortIn(8080);
		} catch (SocketException e) {
			Log.e("SocketException", e.toString());
		}
		OSCListener listener = new OSCListener() {
			public void acceptMessage(java.util.Date time, OSCMessage message) {
				Log.i("OSC", message.getAddress());
			}
		};
		oscPortIn.addListener("/"+prefix+"/led", listener);
		oscPortIn.startListening();
		
		gridDown = new Boolean[8][8];
		for(int i = 0; i < 8; i++)
			for(int j = 0; j < 8; j++)
				gridDown[i][j] = false;
	}
	
	public void setPrefix(String prefix){
		this.prefix = prefix;
	}

	// create a method for the addressChanged action (Set Address)
	public void setAddress() {
		// the variable OSCPortOut tries to get an instance of OSCPortOut at the address

		try {
			oscPortOut = new OSCPortOut(InetAddress.getByName("192.168.1.164"));   //addressWidget.getText()));
			// if the oscPort variable fails to be instantiated then sent the error message
		} catch (Exception e) {
			//showError("Couldn't set address" + e);
		}
		
		Object[] oscArgs = {deviceIPAddress};
		OSCMessage oscMsg = new OSCMessage("/" + prefix + "/setup", oscArgs);

		try {
			oscPortOut.send(oscMsg);
			Log.i("OSC", "Outbound: " + oscMsg.getAddress() + " " + oscArgs[0]);
		} catch (IOException e) {
			Log.e("IOException", e.toString());
		}
		
	}

	protected void onDraw(Canvas canvas) {
		Paint background = new Paint();
		background.setColor(getResources().getColor(R.color.background));

		Paint cell = new Paint();
		cell.setColor(getResources().getColor(R.color.button));

		// draw background
		canvas.drawRect(0, 0, getWidth(), getHeight(), background);
	
		// draw cells
		for (int h = 0; h < 8; h++) {
			for (int w = 0; w < 8; w++) {
				if(gridDown[w][h]) cell.setStyle(Style.FILL); else cell.setStyle(Style.STROKE);
				RectF bounds = new RectF(w * cellSize, h* cellSize, (w * cellSize) + (cellSize -2), (h * cellSize) + (cellSize -2));
;				canvas.drawRoundRect(bounds, 4, 4, cell);
			}
		}
	}

	/* BUG 
	 * To fix:
	 * Press down and drag and release on different square
	 * Dont recieve up if released on different square
	 * 
	 */
	@Override 
	public boolean onTouchEvent(MotionEvent event) { 

		int xPos = (int)event.getX()/cellSize;
		int yPos = (int)event.getY()/cellSize;
		
		if(xPos < 0 || xPos > 7 || yPos < 0 || yPos > 7) return true;
		
		if(event.getAction() == MotionEvent.ACTION_DOWN){
			sendTouch(xPos, yPos, 1);
			Log.i("KeyPress", xPos + " " + yPos + " DOWN");
			gridDown[xPos][yPos] = true;
            MonomeView.this.invalidate();
		}
		
		if(event.getAction() == MotionEvent.ACTION_UP){
			sendTouch(xPos, yPos, 0);
			Log.i("KeyPress", xPos + " " + yPos + " UP");
			gridDown[xPos][yPos] = false;
            MonomeView.this.invalidate();
		}

		return true; 
	} 

	// handler for button grid 
	public void sendTouch(int posX, int posY, int actionCode) {

		Object[] oscArgs = {new Integer(posX), new Integer(posY), new Integer(actionCode)};
		OSCMessage oscMsg = new OSCMessage("/" + prefix + "/press", oscArgs);

		try {
			oscPortOut.send(oscMsg);
			Log.i("OSC", "Outbound: " + oscMsg.getAddress() + " " + oscArgs[0] + " " + oscArgs[1] + " " + oscArgs[2]);
		} catch (IOException e) {
			Log.e("IOException", e.toString());
		}
	}

	public void setDeviceIPAddress(String deviceIPAddress) {
		this.deviceIPAddress = deviceIPAddress;
		Log.i("IP", deviceIPAddress);
	}

}
